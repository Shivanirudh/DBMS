
public class EmployeePayroll {

    public static void main(String[] args) {
        PayrollUI app = new PayrollUI();
        app.setVisible(true);
    }
    
}
 